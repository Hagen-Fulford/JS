console.log("page loaded...");


function play(element){
    console.log(element play);
    element.play();
}

function pause(element){
    console.log(element stop);
    element.pause();
}
